idade = []
nome = []
while True:
    nome.append(input('Digite o nome:'))
    idade.append(int(input('Digite a Idade:')))
    Sair = input ('Digite S para sair:')
    if Sair =='S':
     break
print(nome)