nome = input("Digite o nome do funcionário: ")
horas = int(input("Digite a quantidade de horas trabalhadas: "))
valor_hora = int(input("Digite o valor da hora: "))
 
salario_bruto = horas * valor_hora
 
if salario_bruto <= 1400:
    desconto = 0
elif salario_bruto <= 3000:
    desconto = 2
elif salario_bruto <= 5000:
    desconto = 3.5
else:
    desconto = 5
 
valor_desconto = salario_bruto * (desconto/100)
salario_liquido = salario_bruto - valor_desconto

print("Funcionário:", nome)
print("Salário Bruto: R$", salario_bruto)
print("Desconto: R$", valor_desconto, "(", desconto*100, "% )")
print("Salário Líquido: R$", salario_liquido)