nome=input("What your name? ")
nota1=int (input("Digite o Primeiro Valor: "))
nota2=int (input("Digite o Segundo Numero: "))
nota3 = nota1 + nota2
print ('A soma Total é: ', nota1+nota2)
print ('A media é ',nota3/2)
if nota3/2>7:
    print("Aluno Aprovado")
else:
    print("Aluno Reprovado")