n=3
x=0
while x<3:
    print("Etec-Belém")
    x+=1

for a in range(3):
    print("ETEC - Curso Mobil")