nome_aluno = ''
nome_cliente = []
print(type(nome_aluno))
print(type(nome_cliente))

lista_compras = ['uva','laranja','maça']
for a in lista_compras:
    print(a)

    print(lista_compras[0]) #exibe item posição 0
    print(lista_compras[1]) #exibe item posição 0
    print(lista_compras[-1]) #exibe última posição

    del lista_compras[2] #apaga item posição 2 

    lista_compras.insert(1,'abacaxi')
    print (lista_compras)
    lista_compras.append('goiaba')
    print (lista_compras)
    lista_compras.remove('abacaxi')
    print (lista_compras)