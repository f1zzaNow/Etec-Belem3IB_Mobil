n1=2
n2=20
if n1==n2:
    print('Valor igual')
    print('-----')
else:
    print("Valor Diferente")    
print ("Fim de Programa")



numero=4
if numero==1:
    print('numero um')
elif numero==2:
    print('numero dois')
elif numero==3:
    print('numero três')
elif numero==4:
    print('numero quatro')
elif numero==5:
    print('numero cinco')
else:
    print("Numero Fora da Faixa entre 1 a 5")
    




