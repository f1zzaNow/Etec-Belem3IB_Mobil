print("Aula")

nome="José Carlos" # Variável do tipo String
idade=20
salario=2500.80
estuda = True
 
print('Nome', nome)
print (f'nome {nome}')
print ('aluno: ',nome, 'Idade: ', idade)
print(f"Aluno: {nome } idade: {idade}")

print(type(idade))