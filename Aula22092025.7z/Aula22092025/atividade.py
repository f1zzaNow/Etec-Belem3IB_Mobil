idade = int(input("Digite sua idade: "))
 
if idade == 18:
    print("Igual a 18 anos")
elif idade > 18:
    print("Maior de idade")
else:
    print("Menor de idade")